"""State/alignment and wrench IPC consumers for real episodes.

Native wrench queries belong exclusively to an explicitly supplied spawned
provider. No parent native-wrench fallback is permitted. State/RT remains in
the parent; its native scheduling and controller isolation remain unvalidated.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
import threading
import time
from typing import Any

from collection.episode_logger import EpisodeLogger, EpisodeLoggerError
from collection.state import KinematicStateFrame
from collection.state_buffer import StateBufferOverflow
from hardware.rokae_adapter import RobotWrenchFrame
from hardware.safety_events import safety_event_block_reason
from utils.clock import MonotonicClock, SYSTEM_CLOCK


def _component(values: tuple[float, ...] | None, index: int) -> float | None:
    return None if values is None or len(values) <= index else float(values[index])


def _age_s(now_s: float, sample_s: float | None) -> float | None:
    if sample_s is None or not math.isfinite(sample_s):
        return None
    age = now_s - sample_s
    return age if age >= 0.0 and math.isfinite(age) else None


@dataclass(frozen=True)
class AcquisitionHealth:
    host_time_s: float
    state_time_s: float | None
    wrench_time_s: float | None
    state_age_s: float | None
    wrench_age_s: float | None
    state_wrench_skew_s: float | None
    state_valid: bool
    wrench_valid: bool
    state_thread_alive: bool
    wrench_thread_alive: bool
    alignment_thread_alive: bool
    query_duration_ms: float | None
    force_magnitude_n: float | None
    torque_magnitude_nm: float | None
    valid: bool
    invalid_reason: str
    wrench_process_alive: bool = False
    wrench_stream_healthy: bool = False
    wrench_query_state: str = "NOT_STARTED"
    wrench_failure_latch: tuple[str, ...] = ()


class RealRobotAcquisition:
    """Lifecycle and latest-snapshot cache for one connected episode."""

    def __init__(
        self,
        adapter: Any,
        logger: EpisodeLogger,
        *,
        state_poll_hz: float = 250.0,
        wrench_hz: float = 50.0,
        alignment_hz: float = 50.0,
        join_timeout_s: float = 1.0,
        clock: MonotonicClock = SYSTEM_CLOCK,
        thread_factory: Any | None = None,
        wrench_provider: Any | None = None,
        diagnostic_state_only: bool = False,
    ) -> None:
        for name, value in (
            ("state_poll_hz", state_poll_hz),
            ("wrench_hz", wrench_hz),
            ("alignment_hz", alignment_hz),
        ):
            if not math.isfinite(value) or value <= 0.0:
                raise ValueError(f"{name} must be finite and positive")
        self.adapter = adapter
        self.wrench_provider = wrench_provider
        self.diagnostic_state_only = diagnostic_state_only
        if wrench_provider is not None and wrench_provider.config["rate_hz"] != wrench_hz:
            raise ValueError("provider rate must match explicit acquisition wrench_hz")
        self.logger = logger
        self.state_poll_hz = float(state_poll_hz)
        self.wrench_hz = float(wrench_hz)
        self.alignment_hz = float(alignment_hz)
        if not math.isfinite(join_timeout_s) or join_timeout_s <= 0.0:
            raise ValueError("join_timeout_s must be finite and positive")
        self.join_timeout_s = float(join_timeout_s)
        self.clock = clock
        self._thread_factory = thread_factory or threading.Thread
        if not callable(self._thread_factory):
            raise TypeError("thread_factory must be callable")
        self._stop_event = threading.Event()
        self._state_lock = threading.Lock()
        self._wrench_lock = threading.Lock()
        self._latest_state: KinematicStateFrame | None = None
        self._last_logged_state_sequence: int | None = None
        self._state_capture_enabled = False
        self._latest_wrench: RobotWrenchFrame | None = None
        self._last_logged_wrench_sequence: int | None = None
        self._state_error: str | None = None
        self._wrench_error: str | None = None
        self._background_error: str | None = None
        self._threads: dict[str, threading.Thread] = {}
        self._started_threads: dict[str, threading.Thread] = {}
        self._started = False
        self._manage_connection = True

    @property
    def running(self) -> bool:
        return self._started and not self._stop_event.is_set()

    @property
    def background_error(self) -> str | None:
        return self._background_error

    @property
    def live_producer_names(self) -> tuple[str, ...]:
        """Name producer threads that still own episode/SDK resources."""

        return tuple(
            sorted(name for name, thread in self._threads.items() if thread.is_alive())
        )

    def _thread_alive(self, name: str) -> bool:
        thread = self._threads.get(name)
        return bool(thread is not None and thread.is_alive())

    def start(self, *, manage_connection: bool = True) -> "RealRobotAcquisition":
        """Start observation producers after the five-file logger is ready."""
        if self._started:
            raise RuntimeError("real robot acquisition is already started")
        if self.wrench_provider is None and not self.diagnostic_state_only:
            raise PermissionError("explicit isolated wrench provider and reviewed budgets required before connection")
        if self.wrench_provider is not None and self.wrench_provider.config["mode"] == "live":
            native = self.adapter.native_robot
            for child_key, parent_key in (("robot_ip", "ip_address"), ("local_ip", "local_ip"), ("robot_class", "robot_class")):
                if self.wrench_provider.config[child_key] != getattr(native, parent_key, None):
                    raise PermissionError("parent_child_connection_binding_mismatch:" + child_key)
        self.logger.assert_healthy()
        self._manage_connection = bool(manage_connection)
        self._started_threads = {}
        try:
            if manage_connection:
                self.adapter.connect()
            connected = self.adapter.is_connected()
            if not connected:
                raise ConnectionError("ROKAE adapter connection was not confirmed")
            if self.wrench_provider is not None and self.wrench_provider.config["mode"] == "live":
                metadata = self.adapter.read_robot_metadata()
                expected = self.wrench_provider.config["expected_identity"]
                for key, parent_key in (("robot_model", "robot_model"), ("robot_serial", "robot_serial_number"),
                                        ("controller_version", "controller_version"), ("sdk_version", "xcore_sdk_version")):
                    if str(metadata.get(parent_key)) != expected[key]:
                        raise PermissionError("parent_child_identity_binding_mismatch:" + key)
            self.adapter.start_state_stream()
            if all(callable(getattr(self.adapter, name, None)) for name in
                   ("begin_state_capture", "drain_state_frames", "end_state_capture")):
                self._state_capture_enabled = self.adapter.begin_state_capture() is True
            if self.wrench_provider is not None:
                self.wrench_provider.start()
            self._stop_event.clear()
            self._threads = {
                "state": self._thread_factory(
                    target=self._state_loop,
                    name="real-episode-state",
                    daemon=True,
                ),
                "wrench": self._thread_factory(
                    target=self._wrench_loop,
                    name="real-episode-wrench",
                    daemon=True,
                ),
                "alignment": self._thread_factory(
                    target=self._alignment_loop,
                    name="real-episode-alignment",
                    daemon=True,
                ),
            }
            self._started = True
            for name, thread in self._threads.items():
                try:
                    thread.start()
                except BaseException:
                    # A custom/native thread wrapper may report a start error
                    # after spawning.  Track it whenever it is in fact alive.
                    if thread.is_alive():
                        self._started_threads[name] = thread
                    raise
                self._started_threads[name] = thread
            return self
        except Exception as exc:
            self._stop_event.set()
            for thread in self._started_threads.values():
                if thread is not threading.current_thread():
                    thread.join(timeout=self.join_timeout_s)
            still_alive = sorted(
                name
                for name, thread in self._started_threads.items()
                if thread.is_alive()
            )
            start_reason = f"acquisition_start:{type(exc).__name__}:{exc}"
            self._started = False
            if still_alive:
                if self.wrench_provider is not None and self.wrench_provider.process is not None:
                    self.wrench_provider.stop()
                reason = (
                    start_reason
                    + ";acquisition_threads_did_not_stop:"
                    + ",".join(still_alive)
                )
                self._background_error = reason
                self.logger.signal_failure(reason, stream="acquisition_start")
                raise RuntimeError(
                    reason
                    + "; refusing SDK cleanup/disconnect while a producer "
                    "may still own native resources"
                ) from exc
            self._background_error = start_reason
            self.logger.signal_failure(start_reason, stream="acquisition_start")
            try:
                self.logger.mark_failed(start_reason)
            except EpisodeLoggerError:
                pass
            if self.wrench_provider is not None and self.wrench_provider.process is not None:
                self.wrench_provider.stop()
            self._cleanup_adapter(persist_state_tail=False)
            raise

    def stop(self) -> None:
        """Stop producers without racing disconnect against a blocked SDK call.

        xCoreSDK exposes no timeout/cancellation argument for ``getEndTorque``.
        If any producer fails to join, this method deliberately leaves the SDK
        session untouched and raises for supervised/manual recovery.
        """
        self._stop_event.set()
        for thread in self._started_threads.values():
            if thread is not threading.current_thread():
                thread.join(timeout=self.join_timeout_s)
        still_alive = list(self.live_producer_names)
        if still_alive:
            if self.wrench_provider is not None and self.wrench_provider.process is not None:
                self.wrench_provider.stop()
            reason = "acquisition_threads_did_not_stop:" + ",".join(sorted(still_alive))
            self._background_error = reason
            # Do not inspect logger.healthy or call mark_failed here: either can
            # wait on the logger I/O lock held by the producer we just failed to
            # join.  This path must publish only the lock-free signal and leave
            # both SDK cleanup and metadata untouched.
            self.logger.signal_failure(reason, stream="acquisition_stop")
            self._started = False
            raise RuntimeError(
                reason
                + "; refusing SDK disconnect while a native query may still be active"
            )
        try:
            wrench_log_error = None
            if self.wrench_provider is not None:
                # All consumers have joined. Health polling may have published
                # one unlogged frame, and stop can finish one in-flight query.
                # Snapshot before stopping so the latter cannot overwrite it;
                # stop the provider before doing any potentially blocking I/O.
                before_stop = self.wrench_provider.last_good
                self.wrench_provider.stop()
                try:
                    self._persist_wrench_frame(before_stop)
                    self._persist_wrench_frame(self.wrench_provider.last_good)
                except Exception as exc:
                    wrench_log_error = exc
            self._cleanup_adapter()
            if wrench_log_error is not None:
                raise wrench_log_error
        except Exception as exc:
            reason = f"acquisition_cleanup:{type(exc).__name__}:{exc}"
            self._background_error = reason
            self.logger.signal_failure(reason, stream="acquisition_cleanup")
            try:
                self.logger.mark_failed(reason)
            except EpisodeLoggerError:
                pass
            raise
        finally:
            self._started = False

    def _cleanup_adapter(self, *, persist_state_tail: bool = True) -> None:
        logger_failure_event = getattr(self.logger, "failure_event", None)
        logger_failed = bool(
            logger_failure_event is not None
            and callable(getattr(logger_failure_event, "is_set", None))
            and logger_failure_event.is_set()
        )
        persist_state_tail = bool(persist_state_tail and not logger_failed)
        try:
            self.adapter.stop_state_stream()
            if self._state_capture_enabled:
                try:
                    # The source has stopped, so this drain includes every
                    # accepted tail frame before disconnect clears its cache.
                    if persist_state_tail:
                        for frame in self.adapter.drain_state_frames():
                            self._persist_state_frame(frame)
                finally:
                    self.adapter.end_state_capture()
                    self._state_capture_enabled = False
        finally:
            if self._manage_connection:
                self.adapter.disconnect()

    def _sleep_until(self, deadline_s: float) -> float:
        # On Windows, Event.wait can round millisecond waits up to the
        # scheduler tick. Python's time.sleep uses a high-resolution timer.
        # Bound each sleep so even low-rate loops observe stop promptly; this
        # is a scheduling quantum, not a hardware stop guarantee.
        while not self._stop_event.is_set():
            remaining = deadline_s - self.clock.now_s()
            if remaining <= 0.0:
                break
            time.sleep(min(remaining, 0.002))
        return self.clock.now_s()

    def _background_failure(self, producer: str, exc: BaseException) -> None:
        reason = f"{producer}:{type(exc).__name__}:{exc}"
        self._background_error = reason
        self._stop_event.set()
        self.logger.signal_failure(reason, stream=producer)

    def _persist_state_frame(self, frame: KinematicStateFrame) -> None:
        """Write pending history without making health regress to an old frame."""
        if not isinstance(frame, KinematicStateFrame):
            raise TypeError("state capture must return KinematicStateFrame")
        if frame.sequence_id == self._last_logged_state_sequence:
            return
        self.logger.append_robot_state(
            host_time_s=frame.host_monotonic_time_s,
            **{
                f"q{index + 1}": _component(frame.joint_position_rad, index)
                for index in range(6)
            },
            tcp_x=_component(frame.tcp_position_m, 0),
            tcp_y=_component(frame.tcp_position_m, 1),
            tcp_z=_component(frame.tcp_position_m, 2),
            tcp_rx=_component(frame.tcp_orientation_rad, 0),
            tcp_ry=_component(frame.tcp_orientation_rad, 1),
            tcp_rz=_component(frame.tcp_orientation_rad, 2),
            valid=frame.valid,
            invalid_reason=frame.invalid_reason,
        )
        self._last_logged_state_sequence = frame.sequence_id

    def _state_loop(self) -> None:
        period = 1.0 / self.state_poll_hz
        next_tick = self.clock.now_s()
        while not self._stop_event.is_set():
            try:
                # Read health before destructively draining queued history;
                # a failed snapshot must not discard a pending batch.
                frame = self.adapter.read_state_frame()
                if not isinstance(frame, KinematicStateFrame):
                    raise TypeError("read_state_frame must return KinematicStateFrame")
                frames = (self.adapter.drain_state_frames() if self._state_capture_enabled
                          else (frame,))
                # Publication can advance while a batch is being drained.
                # Keep live health at its newest frame, never at a backlog item.
                if frames and frames[-1].sequence_id > frame.sequence_id:
                    frame = frames[-1]
                with self._state_lock:
                    self._latest_state = frame
                    self._state_error = None
                for captured in frames:
                    self._persist_state_frame(captured)
            except StateBufferOverflow as exc:
                self._background_failure("state_buffer", exc)
                return
            except EpisodeLoggerError as exc:
                self._background_failure("state_logger", exc)
                return
            except Exception as exc:
                with self._state_lock:
                    self._state_error = f"state_read:{type(exc).__name__}:{exc}"
            next_tick += period
            now_s = self._sleep_until(next_tick)
            if now_s - next_tick > period:
                next_tick = now_s

    def _persist_wrench_frame(self, frame: RobotWrenchFrame | None) -> None:
        """Append an acknowledged frame once, including shutdown tail frames.

        Called by the wrench consumer, or by stop only after consumers join.
        The sequence advances only after a successful write.
        """
        if frame is None:
            return
        if not isinstance(frame, RobotWrenchFrame):
            raise TypeError("read_internal_wrench must return RobotWrenchFrame")
        if frame.sequence_id == self._last_logged_wrench_sequence:
            return
        with self._wrench_lock:
            self._latest_wrench = frame
        self.logger.append_robot_wrench(
            query_start_s=frame.host_query_start_s,
            query_end_s=frame.host_query_end_s,
            publish_time_s=frame.host_publish_s,
            **{
                f"joint_measured_torque_{index + 1}": _component(
                    frame.joint_measured_torque_nm, index
                )
                for index in range(6)
            },
            **{
                f"joint_external_torque_{index + 1}": _component(
                    frame.joint_external_torque_nm, index
                )
                for index in range(6)
            },
            fx=_component(frame.cartesian_force_raw_n, 0),
            fy=_component(frame.cartesian_force_raw_n, 1),
            fz=_component(frame.cartesian_force_raw_n, 2),
            tx=_component(frame.cartesian_torque_raw_nm, 0),
            ty=_component(frame.cartesian_torque_raw_nm, 1),
            tz=_component(frame.cartesian_torque_raw_nm, 2),
            frame_type=frame.raw_force_frame,
            query_duration_ms=frame.query_duration_ms,
            valid=frame.valid,
            invalid_reason=frame.invalid_reason,
        )
        self._last_logged_wrench_sequence = frame.sequence_id

    def _wrench_loop(self) -> None:
        # IPC service frequency is independent of the native query rate.
        period = min(0.002, 1.0 / self.wrench_hz)
        next_tick = self.clock.now_s()
        while not self._stop_event.is_set():
            try:
                if self.wrench_provider is not None:
                    process_health = self.wrench_provider.poll()
                    with self._wrench_lock:
                        self._wrench_error = ";".join(process_health["FAILURE_LATCH"]) or None
                    self._persist_wrench_frame(self.wrench_provider.last_good)
            except EpisodeLoggerError as exc:
                self._background_failure("wrench_logger", exc)
                return
            except Exception as exc:
                with self._wrench_lock:
                    self._wrench_error = f"wrench_read:{type(exc).__name__}:{exc}"
                if self.wrench_provider is not None:
                    self.wrench_provider.fail(self._wrench_error)
            next_tick += period
            now_s = self._sleep_until(next_tick)
            if now_s - next_tick > period:
                next_tick = now_s

    def latest_health(self) -> AcquisitionHealth:
        now_s = self.clock.now_s()
        with self._state_lock:
            state = self._latest_state
            state_error = self._state_error
        with self._wrench_lock:
            wrench = self._latest_wrench
            wrench_error = self._wrench_error
        state_time = state.host_monotonic_time_s if state is not None else None
        wrench_time = wrench.host_monotonic_time_s if wrench is not None else None
        state_age = _age_s(now_s, state_time)
        wrench_age = _age_s(now_s, wrench_time)
        skew = (
            abs(state_time - wrench_time)
            if state_time is not None and wrench_time is not None
            else None
        )
        state_valid = bool(state is not None and state.valid and state_age is not None)
        wrench_valid = bool(wrench is not None and wrench.valid and wrench_age is not None)
        state_alive = self._thread_alive("state")
        wrench_alive = self._thread_alive("wrench")
        alignment_alive = self._thread_alive("alignment")
        reasons = []
        event_reason = safety_event_block_reason(self.adapter)
        if event_reason:
            reasons.append(event_reason)
        # This second supervisor entry can detect failure even if the raw-CSV
        # consumer is held up in logger I/O. poll never waits on child locks/I/O.
        process_health = self.wrench_provider.poll() if self.wrench_provider is not None else {}
        stream_healthy = bool(process_health.get("STREAM_HEALTH"))
        provider_has_sample = bool(process_health.get("LATEST_GOOD_SAMPLE_VALID"))
        if not stream_healthy:
            reasons.append(wrench_error or ";".join(process_health.get("FAILURE_LATCH", ())) or
                           ("DISABLED_FOR_STATIONARY_A" if self.diagnostic_state_only else "wrench_process_not_ready"))
        if self.wrench_provider is not None:
            limits = self.wrench_provider.budgets
            if state_age is None or state_age > limits.state_age_s:
                reasons.append("state_stale_or_unavailable")
                # The robot is stationary during process startup.  Require a
                # currently fresh state before motion, but latch only after the
                # child has produced its first valid wrench sample.  This keeps
                # Windows spawn latency from becoming a false motion fault.
                if state_age is not None and provider_has_sample:
                    self.wrench_provider.fail("state_freshness_failure")
            if wrench_age is None or wrench_age > limits.sample_age_s:
                stream_healthy = False
                reasons.append("wrench_stale_or_unavailable")
            if skew is None or skew > limits.skew_s:
                reasons.append("state_wrench_skew_unavailable_or_exceeded")
                if skew is not None and provider_has_sample:
                    self.wrench_provider.fail("state_wrench_skew_failure")
        if not state_valid:
            reasons.append(state_error or (state.invalid_reason if state else "state_not_ready"))
        if not wrench_valid:
            reasons.append(wrench_error or (wrench.invalid_reason if wrench else "wrench_not_ready"))
        if not state_alive:
            reasons.append("state_thread_not_alive")
        if not wrench_alive:
            reasons.append("wrench_thread_not_alive")
        if not alignment_alive:
            reasons.append("alignment_thread_not_alive")
        unique_reasons = tuple(dict.fromkeys(reason for reason in reasons if reason))
        force_magnitude = (
            math.sqrt(sum(value * value for value in wrench.cartesian_force_raw_n))
            if wrench is not None and wrench.cartesian_force_raw_n is not None
            else None
        )
        torque_magnitude = (
            math.sqrt(sum(value * value for value in wrench.cartesian_torque_raw_nm))
            if wrench is not None and wrench.cartesian_torque_raw_nm is not None
            else None
        )
        return AcquisitionHealth(
            host_time_s=now_s,
            state_time_s=state_time,
            wrench_time_s=wrench_time,
            state_age_s=state_age,
            wrench_age_s=wrench_age,
            state_wrench_skew_s=skew,
            state_valid=state_valid,
            wrench_valid=wrench_valid,
            state_thread_alive=state_alive,
            wrench_thread_alive=wrench_alive,
            alignment_thread_alive=alignment_alive,
            query_duration_ms=wrench.query_duration_ms if wrench else None,
            force_magnitude_n=force_magnitude,
            torque_magnitude_nm=torque_magnitude,
            valid=bool(state_valid and wrench_valid and state_alive and wrench_alive and alignment_alive and stream_healthy and not reasons),
            invalid_reason=";".join(unique_reasons),
            wrench_process_alive=bool(process_health.get("PROCESS_ALIVE")),
            wrench_stream_healthy=stream_healthy,
            wrench_query_state=process_health.get("CURRENT_QUERY_STATE", "NOT_STARTED"),
            wrench_failure_latch=tuple(process_health.get("FAILURE_LATCH", ())),
        )

    def latest_state_frame(self) -> KinematicStateFrame | None:
        """Return the immutable latest cached state without an SDK query."""
        with self._state_lock:
            return self._latest_state

    def _alignment_loop(self) -> None:
        period = 1.0 / self.alignment_hz
        next_tick = self.clock.now_s()
        while not self._stop_event.is_set():
            try:
                health = self.latest_health()
                self.logger.append_aligned_snapshot(
                    host_time_s=health.host_time_s,
                    state_time_s=health.state_time_s,
                    wrench_time_s=health.wrench_time_s,
                    state_age_s=health.state_age_s,
                    wrench_age_s=health.wrench_age_s,
                    state_wrench_skew_s=health.state_wrench_skew_s,
                    state_valid=health.state_valid,
                    wrench_valid=health.wrench_valid,
                    state_thread_alive=health.state_thread_alive,
                    wrench_thread_alive=health.wrench_thread_alive,
                    query_duration_ms=health.query_duration_ms,
                    valid=health.valid,
                    invalid_reason=health.invalid_reason,
                )
            except EpisodeLoggerError as exc:
                self._background_failure("alignment_logger", exc)
                return
            next_tick += period
            now_s = self._sleep_until(next_tick)
            if now_s - next_tick > period:
                next_tick = now_s

    def wait_until_healthy(self, timeout_s: float = 3.0) -> bool:
        deadline = self.clock.now_s() + timeout_s
        while self.clock.now_s() < deadline and not self._stop_event.is_set():
            health = self.latest_health()
            if health.valid:
                return True
            if health.wrench_failure_latch or self._background_error:
                return False
            time.sleep(0.005)
        return False


__all__ = ["AcquisitionHealth", "RealRobotAcquisition"]
